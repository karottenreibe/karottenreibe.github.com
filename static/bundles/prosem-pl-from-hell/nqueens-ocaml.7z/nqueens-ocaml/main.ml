open Printf;;
open Pieces;;
open Solving;;

let usage () =
    printf "Usage: nqueens <n>\nWhere <n> is a positive integer bigger than 0.\n"
in let argc = Array.length Sys.argv
in match argc with
| 0 | 1 -> usage ()
| _ ->
    try
        let n = int_of_string Sys.argv.(1)
        in if n < 1
            then usage ()
            else
                let b = new board n (fun x -> new queen (x,0))
                in let _ = printf "Starting with this board:\n%s\n\n" b#to_s
                in let s = new dumb_solver
                in let is = s#solve b
                in match is with
                | false -> printf "No solution found!\n"
                | true -> printf  "Solution:\n%s\n" b#to_s
    with Failure(e) ->
        usage ()
;;

