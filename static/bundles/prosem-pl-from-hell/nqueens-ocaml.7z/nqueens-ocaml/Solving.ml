class type solver =
    object
        method solve : Pieces.board -> bool
    end

class virtual dumb_solver_base =
    object (self)
        method private lin_to_sq r n =
            ((r mod n), (r/n))

        method private sq_to_lin (x,y) n =
            y*n + x

        method private sort pieces n =
            List.sort (fun a b -> compare (self#sq_to_lin (b#x,b#y) n) (self#sq_to_lin (a#x,a#y) n)) pieces

        method private next (board : Pieces.board) =
            let n = board#size
            in let rec advance pieces lc =
                match pieces with
                | [] -> -1
                | h::t ->
                    let r = self#sq_to_lin (h#x, h#y) n
                    in match (r+1) > lc with
                    | false ->
                        let nc = self#lin_to_sq (r+1) n
                        in h#move_to nc;
                        r+1
                    | true ->
                        let lr = advance t (lc-1)
                        in let nc = self#lin_to_sq (lr+1) n
                        in h#move_to nc;
                        lr+1
            in let lc = self#sq_to_lin (n-1,n-1) n
            in ignore (advance (self#sort board#pieces n) lc);
            board

        method private is_solution (board : Pieces.board) =
            let can_capture_any q l =
                List.exists (fun x -> q#can_capture x) l
            in let rec is_part_solution l =
                match l with
                | [] -> true
                | h::t ->
                    match can_capture_any h t with
                    | true -> false
                    | false -> is_part_solution t
            in is_part_solution board#pieces

        method private is_last (board : Pieces.board) =
            let n = board#size
            in let coords = List.map (fun p -> self#sq_to_lin (p#x, p#y) n) board#pieces
            in let count = List.length coords
            in not (List.exists (fun r -> r < (n*n)-count) coords)

        method virtual solve : Pieces.board -> bool
    end

class dumb_solver =
    object (self)
        inherit dumb_solver_base as base
        method solve (board : Pieces.board) =
            match base#is_solution board with
            | true -> true
            | false ->
                match base#is_last board with
                | true -> false
                | false -> self#solve (base#next board)
    end

