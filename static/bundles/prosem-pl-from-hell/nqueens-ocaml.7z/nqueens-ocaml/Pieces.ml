open Printf

type position = (int * int)

class type piece =
    object
        method x : int
        method y : int
        method move_to : position -> unit
        method can_capture : piece -> bool
        method to_s : string
    end

class virtual piece_base coords =
    object
        val mutable coords = (coords : position)
        method x = let (x,_) = coords in x
        method y = let (_,y) = coords in y
        method move_to _coords =
            coords <- _coords

        method virtual can_capture : piece -> bool
        method virtual to_s : string
    end

class queen coords : piece =
    object (self)
        inherit piece_base coords

        method can_capture piece =
            let straight = (piece#x = self#x or piece#y = self#y)
            in let diagonal = (abs (piece#x - self#x) = abs (piece#y - self#y))
            in straight || diagonal
        method to_s = "Qu"
    end

class board n init =
    object (self)
        val pieces = Array.to_list (Array.init n init)

        method size = n
        method pieces = (pieces : piece list)
        method get (x, y) =
            let filtered = List.filter (fun p -> p#x = x && p#y = y) pieces
            in match filtered with
            | [] -> None
            | h::t -> Some h

        method to_s =
            let border =
                "-" ^ (Array.fold_left (fun acc line ->
                    acc ^ line
                ) "" (Array.make n "---"))
            in let fields =
                Array.init n (fun y ->
                    Array.init n (fun x -> self#get (x, y)))
            in let grid = Array.fold_left (fun acc row ->
                let row =
                    Array.fold_left (fun acc field ->
                        match field with
                        | None -> sprintf "%s|  " acc
                        | Some p -> sprintf "%s|%s" acc p#to_s
                    ) "" row
                in sprintf "%s%s|\n%s\n" acc row border
            ) "" fields
            in sprintf "%s\n%s" border grid
    end

